"""Write target-local OBJ and MJCF assets from SolidCraft's colored OBJ export."""

from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def occurrence_transforms(component_id, components):
    """Return the nonidentity transforms of the component's first placement."""
    transforms = []
    visited = set()
    while component_id:
        if component_id in visited or not components[component_id]["occurrences"]:
            raise ValueError("Target has no canonical occurrence")
        visited.add(component_id)
        occurrence = components[component_id]["occurrences"][0]
        if "transform" in occurrence:
            transforms.append(occurrence["transform"])
        component_id = occurrence["parent"]
    return transforms[::-1]


def local_coordinates(vector, transforms, translate):
    # SolidCraft returns column-major rigid transforms. Undo each root-to-leaf.
    for matrix in transforms:
        source = [v - offset for v, offset in zip(vector, matrix[3])] if translate else vector
        vector = [sum(a * b for a, b in zip(column, source)) for column in matrix[:3]]
    return vector


def values_text(values):
    return " ".join(f"{v:.12g}" for v in values)


def read_diffuse_colors(path):
    colors = {}
    name = None
    if path.is_file():
        for line in path.read_text(encoding="utf-8").splitlines():
            key, _, payload = line.partition(" ")
            if key == "newmtl":
                name = payload
            elif key == "Kd" and name:
                colors[name] = tuple(float(value) for value in payload.split())
    return colors


def read_obj(path, colors, transforms):
    """Rebase the full OBJ and collect its triangular faces by diffuse color."""
    vertices = [None]
    normals = [None]
    faces = defaultdict(list)
    color = (0.6, 0.6, 0.6)
    lines = ["# SolidCraft OBJ export (target-local mm)"]
    for line in path.read_text(encoding="utf-8").splitlines():
        key, _, payload = line.partition(" ")
        if key in {"v", "vn"}:
            vector = local_coordinates([float(v) for v in payload.split()], transforms, key == "v")
            coordinates = values_text(vector)
            table = vertices if key == "v" else normals
            table.append(coordinates)
            line = f"{key} {coordinates}"
        elif key == "o":
            color = (0.6, 0.6, 0.6)
        elif key == "usemtl":
            color = colors[payload]
        elif key == "f":
            corners = []
            for token in payload.split():
                vertex, _, normal = token.partition("//")
                corners.append((int(vertex), int(normal) if normal else None))
            faces[color].append(corners)
        if not line.startswith("#"):
            lines.append(line)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    if not faces:
        raise ValueError("SolidCraft exported an empty OBJ mesh")
    return vertices, normals, faces


def write_color_mesh(path, vertices, normals, faces):
    vertex_ids = dict.fromkeys(v for face in faces for v, _ in face)
    normal_ids = dict.fromkeys(n for face in faces for _, n in face if n is not None)
    with path.open("w", encoding="utf-8") as output:
        for index, vertex in enumerate(vertex_ids, start=1):
            vertex_ids[vertex] = index
            output.write(f"v {vertices[vertex]}\n")
        for index, normal in enumerate(normal_ids, start=1):
            normal_ids[normal] = index
            output.write(f"vn {normals[normal]}\n")
        for face in faces:
            corners = [
                f"{vertex_ids[v]}//{normal_ids[n]}" if n is not None else str(vertex_ids[v])
                for v, n in face
            ]
            output.write(f"f {' '.join(corners)}\n")


def collision_boxes(config):
    target = config.get("target", {})
    if target.get("type", "cuboid") == "cuboid":
        return [([0, 0, 0], [float(mm) / 2000 for mm in config["box_dims"]])]
    voxels = target.get("voxels")
    if not voxels:
        raise ValueError("Voxel config needs occupied coordinates for MuJoCo collision export")
    axes = list(zip(*voxels))
    midpoint = [(min(axis) + max(axis)) / 2 for axis in axes]
    voxel_m = float(target["voxel_size_mm"]) / 1000
    half_size = [voxel_m / 2] * 3
    return [
        ([(index - center) * voxel_m for index, center in zip(voxel, midpoint)], half_size)
        for voxel in voxels
    ]


def write_mujoco(folder: Path, config, transforms):
    """Write meters-scaled visual meshes and cuboid or voxel collision boxes."""
    colors = read_diffuse_colors(folder / "cube.mtl")
    vertices, normals, faces = read_obj(folder / "cube.obj", colors, transforms)
    model = ET.Element("mujoco", model="aprilcube")
    ET.SubElement(model, "compiler", meshdir=".", discardvisual="false")
    assets = ET.SubElement(model, "asset")
    world = ET.SubElement(model, "worldbody")
    body = ET.SubElement(world, "body", name="cube")
    ET.SubElement(body, "freejoint", name="cube_joint")
    for index, (rgb, triangles) in enumerate(sorted(faces.items()), start=1):
        name = f"visual-{index}"
        filename = name + ".obj"
        write_color_mesh(folder / filename, vertices, normals, triangles)
        ET.SubElement(assets, "mesh", name=name, file=filename, scale="0.001 0.001 0.001")
        ET.SubElement(body, "geom", {
            "name": name, "type": "mesh", "mesh": name, "rgba": values_text((*rgb, 1)),
            "contype": "0", "conaffinity": "0", "density": "0", "group": "1",
        })
    for index, (center, half_size) in enumerate(collision_boxes(config), start=1):
        ET.SubElement(body, "geom", {
            "name": f"collision-{index}", "type": "box",
            "pos": values_text(center), "size": values_text(half_size),
            "rgba": "0 0 0 0", "group": "2", "density": "1250",
        })
    ET.indent(model)
    ET.ElementTree(model).write(folder / "cube.xml", encoding="utf-8", xml_declaration=True)

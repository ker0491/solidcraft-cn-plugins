# AprilCube command-line companion

Run this helper with Python 3.10 or later and the native `solidcraft-cli`. Install the current AprilCube plugin for YAML generation. Export works with a saved AprilCube design, including designs from the first plugin release. Pass `--solidcraft-cli /path/to/solidcraft-cli` on `build` or `export` if the executable is outside `PATH`, or set `SOLIDCRAFT_CLI`.

## Export saved targets

```bash
python3 companion/aprilcube_tool.py export design.sc -o targets --3mf --mujoco --thumbnail
```

Each AprilCube component gets a folder named after the component and its numeric ID. It contains the component's saved `config.json`, using that target's coordinate frame in millimetres. Use `--component ID` to select specific components. The export directory must be new.

- `--3mf` adds a single grouped `cube.3mf` for each component, with its black and white bodies in the first occurrence's saved position and orientation.
- `--mujoco` adds `mujoco/cube.obj` and `cube.mtl` for use as a colored, target-local Wavefront model in millimetres. It also writes `cube.xml` and per-color mesh files for MuJoCo. MJCF renders the CAD surfaces in metres and approximates collision with a box or one box per occupied voxel. Keep the files in the same directory.
- `--thumbnail` adds an 800 × 800 isometric `thumbnail.png` of each target, rendered from the SolidCraft model.

The JSON records the original generated dimensions and marker positions. Restore suppressed or rolled-back marker features before exporting the model, and regenerate after editing marker geometry so the exported JSON reflects the design.

## Generate a SolidCraft design from YAML

`build` reads AprilCube generation YAML using PyYAML in the current Python environment (`python3 -m pip install PyYAML`). It supports cuboid grids, voxel coordinates and unions of voxel cuboids. Use `--plugin-folder /path/to/solidcraft-aprilcube` when working with an unpacked plugin instead of the installed package. `--in design.sc` adds the targets to a copy of an existing design.

```bash
python3 companion/aprilcube_tool.py build spec.yaml -o targets.sc --export targets --mujoco --thumbnail
```

The optional `--export` writes the new components' JSON and 3MF alongside the new design. Add `--mujoco` for simulation assets and `--thumbnail` for previews. Choose new output paths.

```yaml
shape:
  type: cuboid
  grid: [2, 1, 1]
dictionary: apriltag_36h11
size:
  tag_size_mm: 24
layout:
  border_cells: 1
  margin_cells: 1
solidcraft:
  first_tag_id: 30
  target_count: 2
  gap_mm: 8
  edge_chamfer_mm: 0.6
  black_recess_mm: 0.25
  inlay_thickness_mm: 0.8
```

Use `markers.ids` for a specific list or range of IDs across the whole batch. YAML imports use the original generator's default tag size and start with sharp edges and flush markers. Set `solidcraft.edge_chamfer_mm` and `solidcraft.black_recess_mm` to change them. The native model uses the saved design's part colors. The original generator applies Bambu Studio extruder assignments.

Set `solidcraft.engraving_text` to engrave a label. Set `solidcraft.engraving_placement` to `"Black marker border"` for lettering inside a marker or `"Outside marker"` for the existing margin. Target dimensions, white border widths and configuration JSON remain the same. `{id}` inserts the target's first marker ID and `{index}` inserts its position in the batch, starting at 1. Quote numeric labels to preserve leading zeros. An empty string leaves engraving disabled.

```yaml
solidcraft:
  engraving_text: "検査 {id} / {index}"
  engraving_font: "Noto Sans CJK JP"
  engraving_placement: "Black marker border"
```

Use the optional `solidcraft.engraving_font` to choose an installed font family with glyphs for the label. The Japanese example requires Noto Sans CJK JP on the machine running SolidCraft. The default is the built-in Liberation Sans.

## Original AprilCube generator

Install `aprilcube==0.3.1` in the current Python environment (`python3 -m pip install aprilcube==0.3.1`). `web` opens AprilCube's local voxel designer, which downloads YAML for either generator. Use `generate` for the original Bambu Studio project, connector attachment, thumbnail, or UV-textured MuJoCo export.

```bash
python3 companion/aprilcube_tool.py web
python3 companion/aprilcube_tool.py generate spec.yaml -o original-target
```

[AprilCube generation documentation](https://github.com/younghyopark/aprilcube/blob/f378a6c0a47fe07b454196c5d7d9d0b6a74dc5ad/docs/usage.md#cli)

#!/usr/bin/env python3
"""Batch import and export for the SolidCraft AprilCube generator."""

import argparse
from collections import Counter
from contextlib import suppress
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import uuid

from mujoco_assets import occurrence_transforms, write_mujoco


PLUGIN_ID = "solidcraft-aprilcube"
ENTRY = "generate-cube"
CONFIG_KEY = "local.aprilcube.config"
FEATURES_KEY = "local.aprilcube.features"
TARGET_KEY = "local.aprilcube.target."
MAX_SPEC_BYTES = 1024 * 1024
MAX_VOXELS = 64
MAX_MARKERS = 300
MAX_VOXEL_COORD = 1000


def command(name, /, **params):
    return {"command": name, "params": params}


def write_json(path, value):
    path.write_text(
        json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


def run_cli(cli, *args):
    process = subprocess.run([cli, *args], capture_output=True, text=True, errors="replace")
    if process.returncode:
        detail = process.stderr.strip() or process.stdout.strip()
        raise ValueError(f"SolidCraft CLI failed: {detail or process.returncode}")


def run_solidcraft(cli, commands, *, design=None, save=None):
    script_commands = commands
    if design is not None:
        script_commands = [command("doc.open", path=str(design), read_only=True), *commands]
    if save is not None:
        script_commands = [*script_commands, command("file.save_as", path=str(save))]
    with tempfile.TemporaryDirectory(prefix="solidcraft-aprilcube-") as temp:
        script = Path(temp) / "commands.json"
        report = Path(temp) / "results.json"
        write_json(script, script_commands)
        run_cli(cli, "run", str(script), "--results", "--json-out", str(report), "--param-check", "strict")
        results = json.loads(report.read_text(encoding="utf-8"))
    if not isinstance(results, list) or len(results) != len(script_commands):
        raise ValueError("Unexpected SolidCraft CLI result")
    if save is not None:
        for warning in results[-1].get("warnings") or []:
            print(f"SolidCraft save: {warning}", file=sys.stderr)
    start = 1 if design is not None else 0
    return results[start:start + len(commands)]


def new_path(path, *, require_design=False):
    path = path.expanduser()
    path = path.parent.resolve() / path.name
    if require_design and path.suffix.lower() != ".sc":
        raise ValueError("The design output needs a .sc extension")
    if os.path.lexists(path):
        raise ValueError(f"Choose a new output path: {path}")
    return path


def saved_design(path):
    path = path.expanduser().resolve(strict=True)
    if not path.is_file() or path.suffix.lower() not in {".sc", ".solidcraft", ".solvecraft", ".json"}:
        raise ValueError(f"Expected a saved SolidCraft design: {path}")
    return path


def file_stamp(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def remove_reservation(path, marker):
    with suppress(FileNotFoundError):
        with path.open("rb") as reservation:
            is_reserved = reservation.read(len(marker) + 1) == marker
        if is_reserved:
            path.unlink()


def thumbnail(cli, design, path, bodies):
    commands = [
        command("doc.open", path=str(design), read_only=True),
        command("browser.visibility", visible=True, isolate=True, items=bodies),
    ]
    for folder in ("sketches", "construction", "origin", "joints"):
        commands.append(command("browser.visibility", visible=False, folder=folder))
    with tempfile.TemporaryDirectory(prefix="solidcraft-aprilcube-") as temp:
        script = Path(temp) / "snapshot.json"
        write_json(script, commands)
        run_cli(cli, "snapshot", str(script), "--out", str(path), "--width", "800",
                "--height", "800", "--view", "iso", "--no-grid", "--no-axes")


def require_complete_geometry(component, metadata, inspect, timeline, timeline_names, body_features):
    """Check generated features for a target with provenance in the saved design."""
    cid = component["id"]
    index = inspect["metadata"].get(f"{TARGET_KEY}{cid}", {})
    saved = metadata.get(FEATURES_KEY, {})
    available = Counter(body_features[name] for name in component["bodies"])
    if isinstance(saved, dict) and saved.get("component") == cid:
        ids = saved.get("ids")
        inlays = saved.get("inlay_ids")
        if not isinstance(ids, list) or not ids or not isinstance(inlays, list) or not inlays:
            raise ValueError(f"Component {cid} has incomplete AprilCube feature metadata")
        # Match ownership as well as the feature IDs. A copy's annotations refer to its source.
        counts = saved.get("inlay_body_counts", [1] * len(inlays))
        if not isinstance(counts, list) or len(counts) != len(inlays):
            raise ValueError(f"Component {cid} has incomplete AprilCube inlay counts")
        expected_bodies = dict(zip(inlays, counts))
        expected_bodies[saved.get("base_feature", index.get("base_feature", ids[0]))] = 1
        checked = ids
    else:
        # First releases recorded no per-feature IDs. Check only explicitly identifiable
        # generated features and avoid interpreting another component's named features.
        names = Counter(component["features"] + component["sketches"])
        checked = []
        expected_bodies = {}
        for fid, row in timeline.items():
            name = row["name"]
            if names.get(name) != timeline_names[name] or not (
                name in {"AprilCube base", "Join voxel block", "Outer edge chamfer", "Cube edge chamfer"}
                or re.fullmatch(r"(?:Marker (?:inlays|pockets) on|Markers on) [+-][XYZ]", name)
                or re.fullmatch(r"Tag \d+ (?:pocket|inlay|\([+-][XYZ]\))", name)
            ):
                continue
            checked.append(fid)
            if name == "AprilCube base" or name.startswith("Marker inlays on ") or name.endswith(" inlay"):
                expected_bodies[fid] = 1
        if "base_feature" in index:
            checked.append(index["base_feature"])
            expected_bodies[index["base_feature"]] = 1
    for fid in checked:
        row = timeline.get(fid)
        if row is None or row.get("rolled_back") or row.get("suppressed") or row.get("error"):
            label = row["name"] if row else f"feature {fid}"
            raise ValueError(f"Component {cid} has an inactive generated feature ({label})")
    missing = sorted(fid for fid, count in expected_bodies.items() if available[fid] < count)
    if missing:
        raise ValueError(f"Component {cid} is missing generated bodies (features {missing})")


def export_targets(cli, design, stage, component_ids, *, include_3mf, include_mujoco, include_thumbnail):
    needs_bodies = include_3mf or include_mujoco or include_thumbnail
    commands = [command("component.list", compact=not needs_bodies)]
    if needs_bodies:
        commands.extend([
            command("document.inspect", bodies=True, timeline="summary"),
            command("inspect.measure", names_only=True),
        ])
    results = run_solidcraft(cli, commands, design=design)
    components = {
        comp["id"]: comp for comp in results[0]["components"] if comp["id"] != 0
    }
    missing = set(component_ids) - components.keys()
    if missing:
        raise ValueError(f"Unknown component IDs: {', '.join(map(str, sorted(missing)))}")
    selected = list(dict.fromkeys(component_ids)) if component_ids else list(components)
    if not selected:
        raise ValueError("The design has no AprilCube components")
    metadata = run_solidcraft(
        cli, [command("component.metadata", component=cid) for cid in selected], design=design,
    )

    names = []
    exports = []
    simulations = []
    thumbnails = []
    if needs_bodies:
        inspect, measure = results[1:]
        timeline = {row["id"]: row for row in inspect["timeline"]}
        timeline_names = Counter(row["name"] for row in timeline.values())
        body_features = {row["name"]: row["feature"] for row in inspect["bodies"]}
        world_bodies = {row["name"] for row in measure["bodies"]}
    for cid, response in zip(selected, metadata):
        metadata = response.get("metadata", {})
        config = metadata.get(CONFIG_KEY)
        if not isinstance(config, dict):
            if component_ids:
                raise ValueError(f"Component {cid} has no AprilCube config")
            continue
        component = components[cid]
        label = re.sub(r"[^A-Za-z0-9_-]+", "-", component["name"]).strip("-_")[:60]
        name = f"{label or 'target'}-{cid}"
        target = stage / name
        target.mkdir()
        write_json(target / "config.json", config)
        names.append(name)
        if needs_bodies:
            # The first evaluated occurrence uses its definition's body names.
            bodies = component["bodies"]
            if not bodies or not set(bodies).issubset(world_bodies):
                raise ValueError(f"Component {cid} has no complete evaluated body set for mesh export")
            require_complete_geometry(component, metadata, inspect, timeline, timeline_names, body_features)
        if include_3mf:
            exports.append(command(
                "file.export", path=str(target / "cube.3mf"), format="3mf",
                objects="component", bodies=bodies,
            ))
        if include_mujoco:
            folder = target / "mujoco"
            folder.mkdir()
            exports.append(command("file.export_obj", path=str(folder / "cube.obj"), bodies=bodies))
            simulations.append((folder, config, occurrence_transforms(cid, components)))
        if include_thumbnail:
            thumbnails.append((target / "thumbnail.png", bodies))

    if not names:
        raise ValueError("The design has no saved AprilCube configs")
    if exports:
        run_solidcraft(cli, exports, design=design)
    if include_3mf:
        for name in names:
            if not (stage / name / "cube.3mf").is_file():
                raise ValueError(f"SolidCraft did not produce the 3MF for {name}")
    for folder, config, transforms in simulations:
        write_mujoco(folder, config, transforms)
    for path, bodies in thumbnails:
        thumbnail(cli, design, path, bodies)
    return names


def publish_targets(stage, output, names):
    output.mkdir()
    moved = []
    try:
        for name in names:
            (stage / name).rename(output / name)
            moved.append(name)
    except (OSError, KeyboardInterrupt):
        for name in reversed(moved):
            (output / name).rename(stage / name)
        output.rmdir()
        raise


def save_design(cli, staged, output):
    # Reserve the path exclusively, then let SolidCraft save with the final link base.
    backup = output.with_suffix(output.suffix + ".bak")
    marker = uuid.uuid4().bytes
    with output.open("xb") as reservation:
        reservation.write(marker)
    try:
        try:
            with backup.open("xb") as reservation:
                reservation.write(marker)
        except FileExistsError as exc:
            raise ValueError(f"Choose a new output path. The backup already exists: {backup}") from exc
        try:
            run_solidcraft(cli, [], design=staged, save=output)
        finally:
            remove_reservation(backup, marker)
    finally:
        remove_reservation(output, marker)


def export_saved(args):
    design = saved_design(args.design)
    output = new_path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".aprilcube-", dir=output.parent) as temp:
        stage = Path(temp)
        stamp = file_stamp(design)
        names = export_targets(
            args.solidcraft_cli, design, stage,
            args.component, include_3mf=args.include_3mf, include_mujoco=args.mujoco,
            include_thumbnail=args.thumbnail,
        )
        if file_stamp(design) != stamp:
            raise ValueError("The saved design changed during export. Run the export again.")
        publish_targets(stage, output, names)
    for name in names:
        print(output / name)


def first(*values):
    return next((value for value in values if value is not None), None)


def mapping(value, label):
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a mapping")
    return value


def integer(value, label):
    if type(value) is int:
        return value
    if isinstance(value, str) and re.fullmatch(r"[+-]?[0-9]+", value.strip()):
        return int(value)
    raise ValueError(f"{label} must be an integer")


def boolean(value, label):
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"true", "yes", "on", "1"}:
        return True
    if text in {"false", "no", "off", "0"}:
        return False
    raise ValueError(f"{label} must be true or false")


def number(value, label):
    if type(value) not in {int, float, str}:
        raise ValueError(f"{label} must be a finite number")
    try:
        result = float(value)
        if math.isfinite(result):
            return result
    except (ValueError, OverflowError):
        pass
    raise ValueError(f"{label} must be a finite number")


def grid_dimensions(value):
    parts = value if isinstance(value, list) else re.split("[x×]", str(value).lower())
    if len(parts) not in {2, 3}:
        raise ValueError("grid must contain two or three positive dimensions")
    dims = [integer(part, "grid dimension") for part in parts]
    if min(dims) < 1:
        raise ValueError("grid must contain two or three positive dimensions")
    if len(parts) == 2:
        rows, columns = dims
        dims = [columns, rows, rows] if columns >= rows else [columns, columns, rows]
    return dims


def xyz(value, label):
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError(f"{label} must be a three-element list")
    return tuple(integer(item, label) for item in value)


def voxel_coordinates(shape_type, shape):
    occupied = set()
    if shape_type == "voxel_grid":
        values = shape.get("voxels")
        if not isinstance(values, list) or not values:
            raise ValueError("shape.voxels must contain at least one voxel")
        occupied.update(xyz(value, "voxel coordinate") for value in values)
    else:
        values = shape.get("cuboids")
        if not isinstance(values, list) or not values:
            raise ValueError("shape.cuboids must contain at least one cuboid")
        for value in values:
            cuboid = mapping(value, "voxel cuboid")
            origin = xyz(cuboid.get("origin", [0, 0, 0]), "cuboid origin")
            size = xyz(cuboid.get("size"), "cuboid size")
            if min(size) < 1 or math.prod(size) > MAX_VOXELS:
                raise ValueError(f"Each voxel cuboid must occupy between 1 and {MAX_VOXELS} voxels")
            occupied.update(itertools.product(*(range(n, n + length) for n, length in zip(origin, size))))
            if len(occupied) > MAX_VOXELS:
                break
    if len(occupied) > MAX_VOXELS:
        raise ValueError(f"SolidCraft supports up to {MAX_VOXELS} occupied voxels per target")
    if any(abs(value) > MAX_VOXEL_COORD for cell in occupied for value in cell):
        raise ValueError(f"Voxel coordinates must be within ±{MAX_VOXEL_COORD}")
    return occupied


def face_count(voxels):
    return sum(
        cell[:axis] + (cell[axis] + step,) + cell[axis + 1:] not in voxels
        for cell in voxels for axis in range(3) for step in (-1, 1)
    )


def marker_cells(dictionary):
    match = re.fullmatch(r"([4-7])x\1_(50|100|250|1000)", dictionary)
    if match:
        return int(match.group(1)) + 2
    sizes = {
        "aruco_original": 7, "apriltag_16h5": 6, "apriltag_25h9": 7,
        "apriltag_36h10": 8, "apriltag_36h11": 8,
    }
    if dictionary in sizes:
        return sizes[dictionary]
    raise ValueError(f"Unknown AprilCube dictionary: {dictionary}")


def set_tag_ids(params, raw, needed):
    if raw is None:
        return
    used = max(1, min(needed, MAX_MARKERS))
    if isinstance(raw, dict):
        nested = first(raw.get("ids"), raw.get("range"))
        if nested is not None:
            if isinstance(nested, dict):
                raise ValueError("marker.ids.ids and marker.ids.range must contain IDs")
            set_tag_ids(params, nested, needed)
            return
        start = integer(raw.get("start", 0), "marker.ids.start")
        count = integer(raw.get("count", needed), "marker.ids.count")
        step = integer(raw.get("step", 1), "marker.ids.step")
        if count < 1 or step == 0:
            raise ValueError("marker.ids requires a positive count and nonzero step")
        raw = [start + i * step for i in range(min(count, used))]
    if isinstance(raw, list):
        raw = ",".join(str(integer(value, "marker ID")) for value in raw[:used])
    elif type(raw) is int:
        raw = str(raw)
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("marker.ids must supply a nonempty ID list or range")
    params["tag_ids"] = raw


def attachment_enabled(spec):
    attachment = first(
        spec.get("attachment"), spec.get("mount"), spec.get("end_effector"),
        spec.get("end_effector_connector"),
    )
    if isinstance(attachment, dict):
        attachment = first(
            attachment.get("enabled"), attachment.get("attach"),
            attachment.get("end_effector_connector"), True,
        )
    if isinstance(attachment, str):
        if attachment.strip().lower().replace("-", "_") in {
            "end_effector_connector", "connector", "robot_connector",
        }:
            return True
    return attachment is not None and boolean(attachment, "attachment.enabled")


def read_yaml(path):
    try:
        import yaml
    except ImportError as exc:
        raise ValueError("YAML import requires PyYAML in the current Python environment") from exc
    with path.open("rb") as source:
        content = source.read(MAX_SPEC_BYTES + 1)
    if len(content) > MAX_SPEC_BYTES:
        raise ValueError("Generation YAML exceeds 1 MiB")
    try:
        return mapping(yaml.safe_load(content), "YAML document")
    except (yaml.YAMLError, RecursionError) as exc:
        raise ValueError(f"Could not read generation YAML: {exc}") from exc


def generation_params(spec):
    if attachment_enabled(spec):
        raise ValueError("Use the generate subcommand for AprilCube connector attachments")
    raw_shape = first(spec.get("shape"), spec.get("target"))
    shape = {"type": raw_shape} if isinstance(raw_shape, str) else mapping(raw_shape, "shape")
    kind = str(first(shape.get("type"), spec.get("type"), "cuboid")).lower()
    marker = mapping(first(spec.get("marker"), spec.get("markers")), "marker")
    size = mapping(spec.get("size"), "size")
    layout = mapping(spec.get("layout"), "layout")
    material = mapping(first(spec.get("material"), spec.get("print"), spec.get("fabrication")), "material")
    native = mapping(spec.get("solidcraft"), "solidcraft")
    if first(material.get("extruder"), spec.get("extruder")) is not None:
        extruder = integer(first(material.get("extruder"), spec.get("extruder")), "extruder")
        if extruder != 1:
            print("Use generate to apply Bambu Studio extruder assignments.", file=sys.stderr)

    dictionary = str(first(spec.get("dictionary"), spec.get("dict"), marker.get("dictionary"), marker.get("dict"), "4x4_50")).lower()
    pixels = marker_cells(dictionary)
    border = number(first(layout.get("border_cells"), layout.get("border_cell"), spec.get("border_cells"), spec.get("border_cell"), 1), "border_cells")
    if not 0 <= border <= 16 or not (border * 2).is_integer():
        raise ValueError("border_cells must be 0–16 in half-cell increments")
    margin = integer(first(layout.get("margin_cells"), layout.get("margin_cell"), spec.get("margin_cells"), spec.get("margin_cell"), 1), "margin_cells")
    invert = boolean(first(marker.get("invert"), material.get("invert"), spec.get("invert"), False), "invert")
    params = {
        "dictionary": dictionary, "border_cells": border, "margin_cells": margin,
        "invert": invert, "edge_chamfer_mm": 0, "black_recess_mm": 0,
    }
    for key in ("first_tag_id", "target_count", "gap_mm", "edge_chamfer_mm", "black_recess_mm", "inlay_thickness_mm"):
        value = first(native.get(key), spec.get(key))
        if value is not None:
            parse = integer if key in {"first_tag_id", "target_count"} else number
            params[key] = parse(value, key)
    for key in ("engraving_text", "engraving_font", "engraving_placement"):
        value = native.get(key)
        if value is None:
            continue
        if not isinstance(value, str):
            raise ValueError(f"solidcraft.{key} must be a string. Put the value in quotes.")
        if value:
            params[key] = value

    tag_size = first(size.get("tag_size_mm"), size.get("tag_size"), marker.get("tag_size_mm"), spec.get("tag_size_mm"), spec.get("tag_size"))
    cell_size = first(size.get("cell_size_mm"), size.get("cell_size"), spec.get("cell_size_mm"), spec.get("cell_size"))
    if tag_size is not None and cell_size is not None:
        raise ValueError("Specify either tag_size_mm or cell_size_mm")
    if kind in {"cuboid", "cube", "box"}:
        x, y, z = grid_dimensions(first(shape.get("grid"), spec.get("grid"), "1x1x1"))
        params["grid"] = f"{x}x{y}x{z}"
        per_target = 2 * (x * y + y * z + z * x)
    elif kind in {"voxel_grid", "voxel_cuboids"}:
        voxels = voxel_coordinates(kind, shape)
        params["voxels"] = ";".join(f"{x},{y},{z}" for x, y, z in sorted(voxels))
        per_target = face_count(voxels)
        voxel_size = first(shape.get("voxel_size_mm"), shape.get("voxel_size"))
        if voxel_size is not None:
            voxel_size = number(voxel_size, "voxel_size_mm")
            if voxel_size <= 0:
                raise ValueError("voxel_size_mm must be positive")
            params["voxel_size_mm"] = voxel_size
            if tag_size is None and cell_size is None:
                cell_size = voxel_size / (pixels + 2 * border)
            else:
                cell = (
                    number(cell_size, "cell_size_mm") if cell_size is not None
                    else number(tag_size, "tag_size_mm") / pixels
                )
                if cell <= 0:
                    raise ValueError("Marker size must be positive")
                face_cells = voxel_size / cell
                if not math.isclose(face_cells, round(face_cells), rel_tol=0, abs_tol=1e-6):
                    raise ValueError("voxel_size_mm must be a whole number of marker cells in AprilCube YAML")
    else:
        raise ValueError(f"Unsupported shape type: {kind}")

    if cell_size is not None:
        params["cell_size_mm"] = number(cell_size, "cell_size_mm")
        if params["cell_size_mm"] <= 0:
            raise ValueError("cell_size_mm must be positive")
    if tag_size is not None:
        params["tag_size_mm"] = number(tag_size, "tag_size_mm")
    elif cell_size is None:
        params["tag_size_mm"] = 30.0
    ids = first(marker.get("ids"), spec.get("ids"), marker.get("id_range"), spec.get("id_range"))
    set_tag_ids(params, ids, per_target * params.get("target_count", 1))
    return params


def plugin_location():
    if os.name == "nt":
        root = Path(os.environ["LOCALAPPDATA"]) / "SolidCraft"
    elif sys.platform == "darwin":
        root = Path.home() / "Library" / "Application Support" / "SolidCraft"
    else:
        root = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "solidcraft"
    return root / "plugins" / PLUGIN_ID


def inspect_generator(cli, plugin_folder):
    report, = run_solidcraft(cli, [command("plugin.inspect", path=str(plugin_folder))])
    manifest = report["manifest"]
    runtime = manifest.get("runtime") or {}
    generator = next((entry for entry in runtime.get("entries", []) if entry.get("name") == ENTRY), None)
    if manifest.get("id") != PLUGIN_ID or generator is None:
        raise ValueError(f"Expected an installed {PLUGIN_ID} package at {plugin_folder}")
    if "dictionary" not in generator.get("input_schema", {}).get("properties", {}):
        raise ValueError("YAML generation requires AprilCube 0.2.0 or later")
    if any(runtime.get("permissions", {}).values()):
        raise ValueError("AprilCube generator requests permissions outside the design")
    if not report["within_host_limits"]:
        raise ValueError(report.get("limits_error", "AprilCube exceeds SolidCraft host limits"))
    return report["approval"]


def build_from_yaml(args):
    design = saved_design(args.design) if args.design else None
    params = generation_params(read_yaml(args.spec.expanduser()))
    output = new_path(args.output, require_design=True)
    export = new_path(args.export) if args.export else None
    if export and (export == output or export in output.parents or output in export.parents):
        raise ValueError("Choose separate paths for the .sc design and the export directory")
    folder = (args.plugin_folder or plugin_location()).expanduser().resolve()
    if not folder.is_dir():
        raise ValueError(f"Install the AprilCube plugin or pass --plugin-folder. Expected {folder}")
    approval = inspect_generator(args.solidcraft_cli, folder)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Reuse the destination name so the staged file has the right design title.
    with tempfile.TemporaryDirectory(prefix=".aprilcube-", dir=output.parent) as temp:
        staged_design = Path(temp) / output.name
        generation = [
            command("plugin.run", path=str(folder), approval=approval, entry=ENTRY, params=params),
        ]
        results = run_solidcraft(args.solidcraft_cli, generation, design=design, save=staged_design)
        if export is None:
            save_design(args.solidcraft_cli, staged_design, output)
        else:
            targets = results[-1]["result"]
            components = [target["component"] for target in targets.get("targets", [targets])]
            export.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix=".aprilcube-", dir=export.parent) as exp_temp:
                stage = Path(exp_temp)
                names = export_targets(
                    args.solidcraft_cli, staged_design, stage, components,
                    include_3mf=True, include_mujoco=args.mujoco, include_thumbnail=args.thumbnail,
                )
                save_design(args.solidcraft_cli, staged_design, output)
                try:
                    publish_targets(stage, export, names)
                except OSError:
                    print(f"Saved design: {output}", file=sys.stderr)
                    raise
    print(output)
    if export:
        for name in names:
            print(export / name)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] in {"generate", "web"}:
        if importlib.util.find_spec("aprilcube") is None:
            print("Install aprilcube==0.3.1 in the current Python environment.", file=sys.stderr)
            return 1
        return subprocess.run([sys.executable, "-m", "aprilcube.cli", *argv]).returncode

    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    cli = argparse.ArgumentParser(add_help=False)
    cli.add_argument(
        "--solidcraft-cli", default=os.environ.get("SOLIDCRAFT_CLI") or "solidcraft-cli",
        help="SolidCraft CLI executable (default: SOLIDCRAFT_CLI or PATH)",
    )
    save = commands.add_parser("export", parents=[cli], help="Extract one config.json per saved target")
    save.add_argument("design", type=Path, help="Saved SolidCraft .sc design")
    save.add_argument("-o", "--output", type=Path, required=True, help="New output directory")
    save.add_argument("--3mf", dest="include_3mf", action="store_true", help="Include per-target two-color 3MF")
    save.add_argument("--mujoco", action="store_true", help="Include per-target colored OBJ and MuJoCo XML")
    save.add_argument("--thumbnail", action="store_true", help="Include a per-target 800 × 800 PNG preview")
    save.add_argument("--component", type=int, action="append", default=[], help="Select component by ID (repeatable)")
    save.set_defaults(handler=export_saved)

    build = commands.add_parser("build", parents=[cli], help="Generate an editable SolidCraft design from AprilCube YAML")
    build.add_argument("spec", type=Path, help="AprilCube YAML generation spec")
    build.add_argument("-o", "--output", type=Path, required=True, help="New .sc design")
    build.add_argument("--in", dest="design", type=Path, help="Add targets to a copy of this design")
    build.add_argument("--plugin-folder", type=Path, help="Unpacked solidcraft-aprilcube package")
    build.add_argument("--export", type=Path, help="New directory for the generated targets' JSON and 3MF")
    build.add_argument("--mujoco", action="store_true", help="Include colored OBJ and MuJoCo XML with --export")
    build.add_argument("--thumbnail", action="store_true", help="Include a per-target PNG preview with --export")
    build.set_defaults(handler=build_from_yaml)

    commands.add_parser("generate", help="Run the original AprilCube generator")
    commands.add_parser("web", help="Open the original AprilCube voxel designer")
    args = parser.parse_args(argv)
    if args.command == "build" and (args.mujoco or args.thumbnail) and args.export is None:
        parser.error("build --mujoco and --thumbnail require --export")
    try:
        args.handler(args)
    except (OSError, ValueError, KeyError, TypeError, OverflowError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

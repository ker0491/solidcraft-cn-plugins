# Fiducial dictionary data

The binary tables contain marker images rendered with OpenCV 4.14.0 and packed for the plugin. Each marker has one black border cell on each side. Rows are top to bottom, stored as little-endian 16-bit masks with the leftmost cell at bit zero. A set bit is black. IDs start at zero in each table.

| Files | Data and license |
| --- | --- |
| `aruco-4x4.bin`, `aruco-5x5.bin`, `aruco-6x6.bin`, `aruco-7x7.bin`, `aruco-original.bin` | OpenCV's [predefined ArUco dictionaries](https://github.com/opencv/opencv/blob/4.14.0/modules/objdetect/src/aruco/predefined_dictionaries.hpp). [Apache 2.0](LICENSE-OpenCV.txt) |
| `apriltag-16h5.bin`, `apriltag-25h9.bin`, `apriltag-36h10.bin`, `apriltag-36h11.bin` | OpenCV's [predefined AprilTag dictionaries](https://github.com/opencv/opencv/blob/4.14.0/modules/objdetect/src/aruco/apriltag/predefined_dictionaries_apriltag.hpp). [Apache 2.0](LICENSE-OpenCV.txt) and [AprilTag BSD 2-Clause notice](LICENSE-AprilTag.txt) |

For each ArUco bit size, the 50-, 100- and 250-marker dictionaries are exact prefixes of the 1000-marker table. The plugin shares that table and enforces the ID range of the selected dictionary.

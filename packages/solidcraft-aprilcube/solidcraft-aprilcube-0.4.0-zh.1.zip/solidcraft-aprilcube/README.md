# AprilCube for SolidCraft

Generate editable, two-color fiducial targets in SolidCraft desktop 0.41.0 or later. Each target is a component with a native CAD feature history and its own AprilCube-compatible configuration. One Undo removes the entire batch.

![Two engraved AprilTag cubes generated in SolidCraft](docs/aprilcube-solidcraft.png)

Use the [AprilCube detector](https://github.com/younghyopark/aprilcube) with the exported tracking configuration to estimate the pose of a printed target from camera images. The SolidCraft plugin requests no file, network, or clock access. The optional command-line companion runs separately.

## Install and generate

1. Download `solidcraft-aprilcube-<version>.zip` from the [latest release](https://github.com/takuto-NA/solidcraft-aprilcube/releases/latest). The release includes a separate SHA-256 checksum.
2. In [SolidCraft desktop](https://github.com/tangency-labs/solidcraft/releases), open **Plugins → Install plugin…** and choose the ZIP. Review the package and select **Install**.
3. Open a design and select **Plugins → AprilCube → Generate targets**. The first run prompts for approval of the package contents.
4. Choose a dictionary and shape, set the first tag ID and target count, then choose **Run**. The batch is centered at the origin in an empty design. In a design with bodies, the batch starts beyond the rightmost body along +X.

In SolidCraft 0.41.0, open **Plugins → AprilCube → Preview settings** to calculate dimensions, marker IDs and batch count before editing the design. On hosts with inline plugin previews, select **Preview** in the **Generate targets** dialog to also see an isometric thumbnail. The thumbnail shows the first target and its visible markers. Dense layouts show marker outlines. The summary includes the first target’s label if you enable engraving.

| Input | Default | Use |
| --- | --- | --- |
| Marker dictionary | `apriltag_36h11` | All 21 AprilCube dictionaries, including ArUco and AprilTag |
| Target count | 1 | Generate up to 8 targets in one run, subject to the design size and dictionary |
| First tag ID | 0 | IDs continue across targets. For six-face cubes starting at 12, three targets use 12–17, 18–23 and 24–29 |
| Explicit tag IDs | Empty | Override the first ID with a comma-separated list or ranges such as `12-17,24-29` |
| Cuboid grid | `1x1x1` | Marker counts along X, Y and Z. For example, `2x2x2` places 24 markers and `5x4x1` places 58 |
| Voxels | Empty | Use semicolon-separated occupied cells such as `0,0,0; 0,0,1; 1,0,1`. Each exposed voxel face gets one marker |
| Voxel side | Auto | Side length in mm. An input of 0 derives it from the marker and border |
| Tag size | 32 mm | Width across the outer black border |
| Cell size | Auto | A positive length in mm overrides Tag size |
| White border | 1 cell | Minimum border in half-cell increments. It grows to clear the chamfer and the pockets |
| Tag spacing | 1 cell | White gap between adjacent markers on a cuboid. Set 0 to join adjacent marker borders |
| Edge chamfer | 0.8 mm | Outer edges, 0–6 mm. Use 0 for sharp edges |
| Inlay recess | 0.2 mm | Distance to the top of the inlay, 0–1 mm. Use 0 for flush markers |
| Inlay thickness | 0.8 mm | Material below the top of the inlay, 0.4–1.6 mm |
| Invert colors | Off | Swap base and inlay colors |
| Target gap | 5 mm | Distance between components in the batch |

The default model is a 40 mm cube. The native generator supports up to 300 markers per batch and up to 64 face-connected voxels per target, within the 256 CAD-call and 30-second limits of SolidCraft 0.41.0. Use a smaller batch for complex targets. The two-color CAD model clips diagonal cell contacts by a small fraction of one cell to produce printable solids.

A zero outer border works with sharp, flush single-marker cubes, zero-spacing cuboids, and voxels sized to the tag. These designs use the base for the dark cells and inlays for the light cells. Keep the inlay thinner than one cell. For other layouts the native generator leaves clearance for the edges and pockets. The original generator also accepts zero-border layouts with a positive gap between neighboring tags.

## Engrave a label

Enter a single line in **Engraving text**. For example, `RIG-{id}` gives `RIG-12` and `RIG-18` on two cubes starting at ID 12. `{id}` means the first marker ID on each target. `{index}` means its position in the batch, starting at 1. Leave the field empty to generate a target without engraving.

Choose **Engraving placement** to control where the lettering goes.

- **Outside marker** uses a 0.30 mm deep cut when an existing blank strip fits the text at least one cell from the tags. On a cuboid with a narrow border, a compact 0.12 mm deep cut can fit on the outer edge of the existing face. The compact text can be below 1 mm high. A voxel target uses a single exposed cell face.
- **Black marker border** centers the outline vertically in the lower black strip of one marker on the −Y side. The plugin can shift the text sideways to clear nominal black sample positions when the outlines allow it. On the standard 40 mm cube with a 32 mm AprilTag 36h11 and a one-cell white border, a 1.76 mm high label leaves 1.12 mm of black on each side vertically. The cut is 0.16 mm deep. The white border, marker outline and data cells stay intact. This placement requires standard marker colors. Reflections from the cut can affect detection and print resolution determines how well the letters come out.

Both placements keep the target dimensions and tracking configuration. The generated component stores the label separately in its metadata. If the text cannot fit, the plugin returns a message and leaves the design unchanged.

The built-in font handles Latin text. For Japanese, enter an installed font family such as **Noto Sans CJK JP** in **Engraving font**. The design stores the resulting outlines, so it can be reopened and exported on another machine.

## Save 3MF and tracking JSON

In SolidCraft, use **Export → 3MF → Objects → Component** for a grouped, two-color 3MF of the whole design. Assign filaments to its parts in your slicer. Use **Plugins → AprilCube → Show tracking JSON** to view and copy the saved geometry. Enter the first ID of a specific target or use `-1` to see all targets.

The companion can save one `config.json` and `cube.3mf` per component in a single command. Add `--thumbnail` for an isometric PNG and `--mujoco` for a colored OBJ and a MuJoCo model. The companion can also generate an editable SolidCraft design from an AprilCube YAML spec.

```sh
python3 companion/aprilcube_tool.py export design.sc -o targets --3mf
```

Each `config.json` contains the dictionary, IDs and corners in millimeters relative to the target's center. The corners account for the inlay recess. The saved configuration describes the generated geometry. Regenerate the target after changing its marker geometry. The companion also exports the configuration saved in version 0.1.0 designs.

For the original voxel designer, connector with mounting rod, Bambu Studio paint assignments, annotated thumbnail and texture-atlas outputs, the companion can invoke the published AprilCube generator. See the [companion guide](companion/README.md).

## Build from source

On Linux, install Rust 1.95 or newer, Python 3, [wasm-tools](https://github.com/bytecodealliance/wasm-tools/releases) and `zip`. Run these commands from the project directory.

```sh
rustup target add wasm32-unknown-unknown
cargo test --locked
./build.sh
```

The installer ZIP is written under `dist/`. To test the archive against the Linux desktop host CLI, run:

```sh
SOLIDCRAFT_CLI=/path/to/solidcraft-cli python3 tests/cli_test.py dist/solidcraft-aprilcube-0.4.0.zip
```

The host test installs the ZIP in a temporary profile and checks generation, placement, Undo, tracking JSON and per-target 3MF exports. GitHub Actions runs the tests on each push. Tags matching both package versions publish the tested ZIP and its checksum.

## License

The plugin and companion use the [MIT License](LICENSE). See [Attribution](ATTRIBUTION.md) for the AprilCube project, dictionary data, WIT interface and bundled notices.

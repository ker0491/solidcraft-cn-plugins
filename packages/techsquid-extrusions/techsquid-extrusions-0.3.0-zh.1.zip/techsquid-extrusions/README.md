# Extrusions

Check the [host requirements](docs/parts-library.md#host-requirements) before installing version 0.3.

Go from a sketch to a frame with configurable T-slot and V-slot rails for [SolidCraft](https://github.com/tangency-labs/solidcraft). Cut rails to length, prepare their joints and add slot nuts without modeling each profile by hand.

![A V-slot track mounted on cross-drilled T-slot feet](examples/v-slot-gantry/v-slot-gantry.png)

- Build MISUMI 5 series T-slot rails in 2020, 2040, 2060, 2080 and 4040 sizes, or OpenBuilds V-slot rails from 2020 through 2080.
- Add M5 tapped ends and screw holes for rail-to-rail connections. Edit a hole reference sketch to move both the access and clearance cuts together.
- Add MISUMI M3, M4 or M5 pre-assembly or post-assembly slot nuts to your rails.
- Place multiple fixed-length copies as reusable components, or create independently editable rails along sketch lines.

## Get started

Open **Plugins > Extrusion** and pick one or more sketch points or circles for **Placement** in the view; clicking inside a circle picks it too. Points or circles already selected when the dialog opens fill the field. Choose a profile, size and length, then press **Run**. With nothing picked, the rail starts at the origin. The default is a 500 mm T-slot 2020 rail.

## Sketch-driven rails

![Paired T-slot 2020, T-slot 4040 and V-slot 2080 rails with path-driven machining](examples/sketch-driven-rails/sketch-driven-rails.png)

Choose **Sketch driven** in the Extrusion dialog and pick straight lines from one
sketch for **Placement**. Each run supports up to 16 lines, all with the chosen
profile. Machining reduces the batch
size under SolidCraft’s command limit; oversized batches are rejected before
creation. Run again for another profile or another batch.
All listed T-slot and V-slot sizes are supported.

Edit the source sketch to move, tilt or resize each rail independently. **Length**
is ignored in this mode. The section and machining share planes derived from the
path, so taps and cross-holes follow without referring to generated rail faces.
**Measure holes from** chooses Start or End for all screw-hole offsets in that run.
Start and End follow the line's drawing direction.

Sketch-driven rails are separate bodies in the active component, grouped in the
timeline. They do not share fixed-length component definitions. Their profile uses
the path-normal construction plane's axes; this differs from Weldments' world-up
orientation. Use the generated section sketch to inspect its X/Y orientation.

Paths must be drawn, non-construction straight lines in a 2D sketch; the sketch can
lie on any plane. Arcs, projected lines and 3D sketch wires are not accepted. The
picked line set is captured when you run the plugin: adding another line later does
not add a rail until you run the plugin on it. Deleting a source line breaks its rail.

At creation, each rail must be 0.01–6000 mm long and fit its requested machining.
Keep it long enough for its holes and taps after editing. A run can model up to four
taps across all rails; use cosmetic threads or smaller batches for more. Geometry
kernel failures roll the plugin run back.

Open the [six-rail example](https://github.com/TechSquidTV/SolidCraft-Plugins/tree/main/examples/sketch-driven-rails) for the saved design and a walkthrough of the path edits.

For a slot nut, sketch a point at the center of the slot on the rail's face, open **Plugins > Slot nut** and pick the point for **Placement**. Choose **Size** for the screw's M3, M4 or M5 thread, then set **Rail runs along** to match the slot.

![A screw through a T-slot foot meets a pre-assembly nut inside the V-slot track](examples/v-slot-gantry/frame-joint.png)

The section shows the pre-assembly M5 nut under the V-slot lips. Open the [gantry example](https://github.com/TechSquidTV/SolidCraft-Plugins/tree/main/examples/v-slot-gantry) to inspect the post-assembly nut at the other foot.

For joint dimensions, tapping limits, slot nut placement and all options, see the [extrusion reference](REFERENCE.md).

## License

[MIT](LICENSE)

The package exposes its insertion tools only. [Shared part-definition and reuse rules](docs/parts-library.md) explain product identity, modified-part preservation and BOM grouping.
